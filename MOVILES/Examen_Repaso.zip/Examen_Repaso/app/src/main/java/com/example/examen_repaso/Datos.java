package com.example.examen_repaso;

import java.util.ArrayList;

public class Datos {
    public ArrayList<Jugador> getDatos(){
        ArrayList<Jugador> jugadores = new ArrayList<>();

        jugadores.add(new Jugador(1, "Álvaro Ratón", 32, "Español",
                "Portero del Ourense CF. Experiencia en categorías superiores.",
                R.drawable.alvaroraton, 0));

        jugadores.add(new Jugador(13, "Alberto Sánchez", 24, "Español",
                "Portero formado en el RC Deportivo Fabril.",
                R.drawable.albertosanchez, 0));

        jugadores.add(new Jugador(5, "Miguel Prado", 26, "Español",
                "Defensa central con buen juego aéreo.",
                R.drawable.miguelprado, 1));

        jugadores.add(new Jugador(4, "Fran Carmona", 26, "Español",
                "Defensa central fuerte en duelos defensivos.",
                R.drawable.francarmona, 0));

        jugadores.add(new Jugador(14, "Adrián Pérez", 22, "Español",
                "Central joven con proyección.",
                R.drawable.adrianperez, 0));

        jugadores.add(new Jugador(22, "Álvaro Yuste", 24, "Español",
                "Defensa central procedente del Alcorcón.",
                R.drawable.alvaroyuste, 1));

        jugadores.add(new Jugador(12, "Aymane Jelbat", 25, "Marroquí",
                "Central físico, buena salida de balón.",
                R.drawable.aymanejelbat, 1));

        jugadores.add(new Jugador(15, "Oriol Comas", 22, "Español",
                "Central formado en el Girona FC.",
                R.drawable.oriolcomas, 0));

        jugadores.add(new Jugador(3, "Hugo Sanz", 23, "Español",
                "Lateral izquierdo rápido y ofensivo.",
                R.drawable.hugosanz, 1));

        jugadores.add(new Jugador(2, "Enol Coto", 24, "Español",
                "Lateral derecho procedente del Amorebieta.",
                R.drawable.enolcoto, 0));

        jugadores.add(new Jugador(18, "David Rabadán", 25, "Español",
                "Mediocentro con buena visión de juego.",
                R.drawable.davidrabadan, 0));

        jugadores.add(new Jugador(8, "Jerin Ramos", 29, "Caboverdiano/Español",
                "Centrocampista polivalente y trabajador.",
                R.drawable.jerin, 2));

        jugadores.add(new Jugador(24, "César Moreno", 24, "Español",
                "Mediocentro del Hércules CF.",
                R.drawable.cesarmoreno, 1));

        jugadores.add(new Jugador(19, "Dani García", 22, "Español",
                "Centrocampista del San Fernando CD.",
                R.drawable.danigarcia, 0));

        jugadores.add(new Jugador(16, "David Muñoz", 20, "Español",
                "Joven mediocentro prometedor.",
                R.drawable.davidmunoz, 0));

        jugadores.add(new Jugador(20, "Lamine Gueye", 19, "Español",
                "Mediocentro del Betis Deportivo.",
                R.drawable.laminegueye, 0));

        jugadores.add(new Jugador(6, "Nacho Castillo", 25, "Español",
                "Mediapunta creativo, llegada al área.",
                R.drawable.nachocastillo, 0));

        jugadores.add(new Jugador(23, "Iker Punzano", 21, "Español",
                "Mediapunta con talento del Villarreal B.",
                R.drawable.ikerpunzano, 1));

        jugadores.add(new Jugador(10, "Marco Camus", 23, "Español",
                "Extremo izquierdo desequilibrante.",
                R.drawable.marcocamus, 0));

        jugadores.add(new Jugador(11, "Aitor Aranzabe", 27, "Español",
                "Extremo con experiencia en Segunda B.",
                R.drawable.aitoraranzabe, 1));

        jugadores.add(new Jugador(17, "Omar Ouhdadi", 25, "Marroquí",
                "Extremo vertical procedente del Bergantiños.",
                R.drawable.omarouhdadi, 2));

        jugadores.add(new Jugador(21, "Adrián Guerrero", 19, "Español",
                "Extremo derecho rápido y habilidoso.",
                R.drawable.adrianguerrero, 0));

        jugadores.add(new Jugador(7, "Amin Bouzaig", 28, "Marruecos/España",
                "Delantero centro potente en el área.",
                R.drawable.amin, 6));

        jugadores.add(new Jugador(9, "Kensly Vázquez", 22, "Haití/España",
                "Delantero rápido y físico.",
                R.drawable.kensly, 4));

        jugadores.add(new Jugador(15, "Juan Piera", 21, "Español",
                "Delantero joven con proyección.",
                R.drawable.juanpiera, 0));

        return jugadores;
    }
}
