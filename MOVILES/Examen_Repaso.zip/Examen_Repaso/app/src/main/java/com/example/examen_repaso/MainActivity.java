package com.example.examen_repaso;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Toolbar toolBar;

    RecyclerView recyclerView;
    ArrayList<Jugador> jugadores;
    JugadoresAdapter adapter;

    //creamos esta variable de TextView, para poder pasarlo como el contructor del Adapter
    TextView txtJugadorSeleccionado;

    //variable que nos ayudara a recordara como esta el recyclerview situado
    // en ese momento de ejecucion de la opcion del menu
    private boolean horizontal = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        toolBar = findViewById(R.id.toolBarMainA);
        setSupportActionBar(toolBar);

        //reusamos el textview que se nos indico que pudieramos debajo de la toolBar
        // en el punto dos para poder usarlo ahora
        txtJugadorSeleccionado = findViewById(R.id.textView);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        jugadores = new Datos().getDatos();

        adapter = new JugadoresAdapter(jugadores, txtJugadorSeleccionado);

        recyclerView.setAdapter(adapter);


    }

    //implementamo el menu con la funcion que aparece en la pg.14
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu_mainacitvity,menu);
        return true;
    }

    //en si en el xml solo hay que diseñar el menu y colocar todo, todo el codigo va aqui en el main
    //en esta funcion de aqui que esta en la pg.14 tambien y que pegas tal cual y que solo ajustas lo de dentro
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if (id==R.id.insertar){

            //lanzamos la acticity
            Intent intent = new Intent(MainActivity.this, InsertarActivity.class);

            startActivity(intent);

            return true;

        }else if (id==R.id.borrar){

            //recorremos la lista de jugadores porque es el que tiene la info de
            // los jugadores incluido ese boolean para hacer lo de los chequeos anteriores
            //y como vamos a borrar elementos, tenemos que recorrerla hacia atras, ya sabes

            for(int i = jugadores.size()-1; i >= 0; i--){

                if(jugadores.get(i).getElegido()){

                    jugadores.remove(i);

                }
            }

            //IMPORTANTE
            //despues de cada eliminacion que se haga, tenemos que notificar al adapter
            adapter.notifyDataSetChanged();

            return true;

        }else if (id==R.id.listar){

            //volvemos a lanzar otra acitvity diferente
            Intent intent = new Intent(MainActivity.this, ListarActivity.class);

            startActivity(intent);

            return true;

        }else if (id==R.id.horizontal){

            if(!horizontal){

                recyclerView.setLayoutManager(
                        new StaggeredGridLayoutManager(
                                2,
                                StaggeredGridLayoutManager.HORIZONTAL
                        )
                );

                horizontal = true;

            }else{

                recyclerView.setLayoutManager(
                        new StaggeredGridLayoutManager(
                                2,
                                StaggeredGridLayoutManager.VERTICAL
                        )
                );

                horizontal = false;

            }

            return true;
        };
        return super.onOptionsItemSelected(item);
    }
}
