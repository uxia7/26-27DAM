package com.example.examen_repaso;

import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class JugadoresAdapter extends RecyclerView.Adapter<JugadoresAdapter.ViewHolder>  {

    private ArrayList<Jugador> listaJugadores;

    //Al marcar la celda, deberá aparecer el nombre del jugador en el TextView de
    //encima del RecyclerView
    private TextView txtJugadorSeleccionado;

    public JugadoresAdapter(ArrayList<Jugador> listaJugadores, TextView txtJugadorSeleccionado) {
        this.listaJugadores = listaJugadores;
        this.txtJugadorSeleccionado = txtJugadorSeleccionado;
    }

    @NonNull
    @Override
    public JugadoresAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.celda, parent, false);

        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull JugadoresAdapter.ViewHolder holder, int position) {
        Jugador jugador = listaJugadores.get(position);

        holder.txtDorsal.setText(String.valueOf(jugador.getDorsal()));
        holder.txtNombre.setText(jugador.getNombreCompleto());
        holder.txtEdad.setText(String.valueOf(jugador.getEdad()));
        holder.txtNacionalidad.setText(jugador.getNacionalidad());
        holder.imgJugador.setImageResource(jugador.getImagen());

        //justo aqui que es donde recogemos los datos de jugador es donde comprobamos si esta seleccionado o no
        if(jugador.getElegido()){
            holder.itemView.setBackgroundColor(Color.WHITE);
        }
        //para gestionar el click de las celdas
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!jugador.getElegido()){

                    jugador.setElegido(true);

                    holder.itemView.setBackgroundColor(Color.WHITE);

                    //depaso que cambiamos el color del fondo para saber si se clicko en el jugador o no
                    //para poner el nombre del jugador completo cuando se pulsa sobre el y detectarlo
                    txtJugadorSeleccionado.setText(jugador.getNombreCompleto());

                    //luego tambien añadimos lo del apartado C) porque tiene que ver con el click
                    //y como es con el jugador clickado en ese momento, es aqui donde lanzamos el TOAST con la info
                    Toast.makeText(v.getContext(), jugador.getNombreCompleto() + "\n" + jugador.getGoles(),Toast.LENGTH_SHORT).show();

                }else{
                    //en este else es que
                    /*
                    claro por ejemplo, al pulsar por primera vez se ejecuta el if y aunque clickes un jugador nuevo
                    se volvera al if, en cambio, si volvemos a clickar sobre el mismo jugador el if ya no se ejecutara con
                    lo cual ya entramos dentro del else y es cuando se abre el intent y ahora es cuando diseñamos la nueva activity
                    * */
                    Intent intent = new Intent(v.getContext(), DetalleActivity.class);

                    //le pasamos el jugardor al nuevo activity
                    intent.putExtra("jugador", jugador);

                    v.getContext().startActivity(intent);

                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return listaJugadores.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgJugador;
        TextView txtDorsal;
        TextView txtNombre;
        TextView txtEdad;
        TextView txtNacionalidad;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgJugador = itemView.findViewById(R.id.imgJugador);
            txtDorsal = itemView.findViewById(R.id.txtDorsal);
            txtNombre = itemView.findViewById(R.id.txtNombreCompleto);
            txtEdad = itemView.findViewById(R.id.txtEdad);
            txtNacionalidad = itemView.findViewById(R.id.txtNacionalidad);

        }
    }
}
