package com.example.examen_repaso;

import java.io.Serializable;

public class Jugador implements Serializable {
    private int dorsal;
    private String nombreCompleto;
    private int edad;
    private String nacionalidad;
    private String descripcion;
    private int imagen;
    private int goles;

    //la var para saber si esta o no seleccionado ese jugador en ese momentoç
    private boolean elegido;

    public Jugador(int dorsal, String nombreCompleto, int edad,
                   String nacionalidad, String descripcion,
                   int imagen, int goles) {

        this.dorsal = dorsal;
        this.nombreCompleto = nombreCompleto;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
        this.descripcion = descripcion;
        this.imagen = imagen;
        this.goles = goles;
        this.elegido = false;
        //tenemos que añadirlo aqui tambien y lo ponemos a false en un principio

    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public int getGoles() {
        return goles;
    }

    public void setGoles(int goles) {
        this.goles = goles;
    }


    //le ponemos sus correspondientes setters y getters
    public boolean getElegido() {
        return elegido;
    }

    public void setElegido(boolean elegido) {
        this.elegido = elegido;
    }
}
