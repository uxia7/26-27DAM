package com.example.examen_repaso;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetalleActivity extends AppCompatActivity {

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detalle);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        toolbar = findViewById(R.id.toolbar);

        //hay que tener cuidado con el impot
        //en caso de que hagamos esto del setSupport y salga error, entonces es que tenemos mal el import
        //borramos el antiguo y lo volvemos a importar
        setSupportActionBar(toolbar);

        //ahora recogemos la informacion del adapter que le enviamos al nuevoAcitvity
        Jugador jugador = (Jugador) getIntent().getSerializableExtra("jugador");

        getSupportActionBar().setTitle(jugador.getNombreCompleto());

        //esto es para mostrar la flecha hacia atras del toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //vale comentarios del xml
        /*
        la imagen al 75%
        añadimos la ImageView justo debajo del Toolbar, hay que tener en cuenta
        layaout_heigth -> 0 dp
        layaout_width -> match parent, porque tiene que ocupar todo
        para lo del 75% tenemos que movernos al WEIGHT ten cuidado porque no es lo mismo,
        es lo que te dije del peso y como es un 75% lo ponemos a 0.75
        y luego tenemos el ScaleType -> fitcenter, para que se quede en el medio

        ------------------------------------------------------------------------------------

        luego esta el apartado del textView con posibilidad de scroll
        para poder hacer eso, lo que tenemos que hacer es usar el componente ScrollView
        y dentro de ese componente meter el TextView para que se pueda hacer el scroll
        por lo demas el mismo proceso que la anterior con los layaout_heigth-width y el WEIGTH al 0.25
        * */

        //con todo esto hecho, la nueva activity ya esta acabada, ahora vamos al menu
    }

    //para que lo ultimo de la flecha hacia atras que le activamos al toolbar funcione
    @Override
    public boolean onSupportNavigateUp() {

        finish();

        return true;
    }
}